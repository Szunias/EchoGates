using UnityEngine;

public class NpcInteractable : MonoBehaviour
{
    public void Interact()
    {
        Debug.Log("Interact!");
    }

}
