using UnityEngine;

public class ItemController : MonoBehaviour
{
    public Item item;
}
