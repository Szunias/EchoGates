﻿using UnityEngine;
using TMPro;

public class TutorialScript : MonoBehaviour
{
    [Header("Referencja do komponentu TMP_Text")]
    [SerializeField] private TMP_Text messageText;

    [Header("Treść komunikatu")]
    [SerializeField] private string message = "Witaj w strefie!";

    private bool _hasTriggered = false;
    private Collider _col;

    private void Awake()
    {
        if (messageText == null)
            Debug.LogError("Brak przypisanego TMP_Text!");
        else
            messageText.enabled = false;  // na start wyłączamy sam rendering tekstu

        _col = GetComponent<Collider>();
        if (_col == null)
            Debug.LogError("TutorialScript wymaga Collidera na tym obiekcie!");
        else if (!_col.isTrigger)
            Debug.LogWarning("Collider nie jest oznaczony jako Is Trigger!");
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!_hasTriggered && other.CompareTag("Player"))
        {
            Debug.Log("Trigger aktywowany przez gracza");
            _hasTriggered = true;

            if (messageText != null)
            {
                messageText.text = message;
                messageText.enabled = true;  // pokazujemy tekst
            }
        }
    }

    private void Update()
    {
        // jak już pokazaliśmy tekst i jest widoczny, czekamy na dowolny klawisz
        if (_hasTriggered && messageText != null && messageText.enabled)
        {
            if (Input.anyKeyDown)
            {
                messageText.enabled = false;  // ukrywamy tekst
                if (_col != null)
                    _col.enabled = false;    // wyłączamy trigger, żeby już nie odpalać
                enabled = false;             // wyłączamy cały skrypt
            }
        }
    }
}
